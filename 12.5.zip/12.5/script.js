// Name: Divine Chinecherem Nnamdi
// Matricule:  LMUI-24SWE287

function checkNumber(val1) {
  try {
    if (isNaN(val1)) {
        throw new Error(`${val1} is not number`);
   }
   else {
        console.log("Got a number");
        }
    } 
    catch (error) {
            console.log("Error:", error.message);
        } 
    finally {
    console.log("The value is:", val1);
        }
    }

    checkNumber("Brick"); 
    checkNumber(52);  
        